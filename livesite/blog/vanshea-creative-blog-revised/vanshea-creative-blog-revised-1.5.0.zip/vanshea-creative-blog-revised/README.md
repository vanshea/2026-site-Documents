# Van Shea Creative Blog Revised

Version 1.5.0 of the custom Van Shea Creative WordPress theme.

## Revision highlights

- Adds a fifth switcher theme, Midnight (theme5): the portfolio's navy dark palette with cyan and violet accents and glass cards.

- Uses the latest responsive footer artwork.
- Includes Schedule Time and LinkedIn footer actions.
- Matches the main site theme names: Clear, Tinted, High Contrast, and Wild, plus the new Midnight.
- Makes Wild the default while preserving visitor and Customizer preferences.
- Keeps the header logo theme-driven so Clear uses the dark mark.
- Bundles the updated dark and light logo marks inside the theme.
- Retains featured-image repair support for imported posts.

## Requirements

- WordPress 6.0 or newer
- PHP 7.4 or newer

Activate **Van Shea Creative Blog Revised** from Appearance > Themes.
