<?php
/**
 * Footer template.
 *
 * @package VanSheaCreativeBlog
 */
?>
</main>

<?php
$footer_text   = get_theme_mod( 'vsc_footer_text', __( 'Van Shea Sedita. All rights reserved.', 'vanshea-creative-blog' ) );
$footer_art    = get_theme_mod( 'vsc_footer_art', get_template_directory_uri() . '/assets/footer-art/site-footer-02_all-02.png' );
$default_theme = vanshea_creative_blog_get_default_theme();
$theme_choices = vanshea_creative_blog_theme_choices();
?>

<footer class="site-footer" id="siteFooter">
	<?php if ( get_theme_mod( 'vsc_show_footer_art', true ) && $footer_art ) : ?>
		<div class="site-footer-art" aria-hidden="true">
			<img
				src="<?php echo esc_url( $footer_art ); ?>"
				alt=""
				width="3128"
				height="3429"
				loading="lazy"
				decoding="async"
			>
		</div>
	<?php endif; ?>
	<div class="site-footer-inner">
		<p>&copy; <span id="year"><?php echo esc_html( gmdate( 'Y' ) ); ?></span> <?php echo esc_html( $footer_text ); ?></p>
		<?php if ( get_theme_mod( 'vsc_show_theme_switcher', true ) ) : ?>
			<div class="theme-switcher" role="group" aria-label="<?php esc_attr_e( 'Choose site theme', 'vanshea-creative-blog' ); ?>">
				<?php foreach ( $theme_choices as $theme_slug => $theme_label ) : ?>
					<button
						class="theme-link<?php echo $theme_slug === $default_theme ? ' is-active' : ''; ?>"
						type="button"
						data-theme="<?php echo esc_attr( $theme_slug ); ?>"
						aria-pressed="<?php echo $theme_slug === $default_theme ? 'true' : 'false'; ?>"
					>
						<?php echo esc_html( $theme_label ); ?>
					</button>
				<?php endforeach; ?>
			</div>
		<?php endif; ?>
	</div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
